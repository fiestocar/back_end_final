<ul>
    <li><?php echo anchor('kategori_anggota','Kategori Anggota'); ?></li>
    <li><?php echo anchor('jenis','Jenis Mobil'); ?></li>
    <li><?php echo anchor('wilayah','Wilayah Operasi') ?></li>
    <li><?php echo anchor('kondisi','Kondisi Mobil') ?></li>
    <li><?php echo anchor('denda','Jenis Denda') ?></li>
    <li><?php echo anchor('anggota','Data Anggota') ?></li>
    <li><?php echo anchor('mobil','Data Mobil') ?></li>
</ul>
